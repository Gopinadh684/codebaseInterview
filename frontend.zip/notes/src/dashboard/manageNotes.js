/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import React , { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {  Container, Header, Form,TextArea , Input, Segment, Button, Table, TableHeader} from 'semantic-ui-react';
import styled from 'styled-components';
import {  listNotes } from '../actions/noteActions';

function ManageNotes(){

  const noteList = useSelector((state) => state.noteLists);
  const { loading, notes, error } = noteList;
  const dispatch = useDispatch();
  useEffect(() => {

    dispatch(listNotes());
        return () => {

    };
  }, []);
    return(
        <div>
            <Table>
               {notes.map((note, index) =>(
                   <Table.Row key={index}>
                       <Table.Cell>{note.title}</Table.Cell>
                       <Table.Cell>{note.notes}</Table.Cell>
                   </Table.Row>
               ))}
            </Table>
        </div>
    )
}

export default ManageNotes;