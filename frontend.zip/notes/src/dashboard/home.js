import React from 'react';
import Notes from './note';
function Home() {
    return (
        <div>
            <Notes/>
        </div>
    )
}
 export default Home;